//
//  Generated file. Do not edit.
//

// clang-format off

#import "GeneratedPluginRegistrant.h"

#if __has_include(<zebra_plugin/ZebraPlugin.h>)
#import <zebra_plugin/ZebraPlugin.h>
#else
@import zebra_plugin;
#endif

@implementation GeneratedPluginRegistrant

+ (void)registerWithRegistry:(NSObject<FlutterPluginRegistry>*)registry {
  [ZebraPlugin registerWithRegistrar:[registry registrarForPlugin:@"ZebraPlugin"]];
}

@end
