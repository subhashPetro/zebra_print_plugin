//
//  Generated file. Do not edit.
//

import FlutterMacOS
import Foundation

import zebra_plugin

func RegisterGeneratedPlugins(registry: FlutterPluginRegistry) {
  ZebraPlugin.register(with: registry.registrar(forPlugin: "ZebraPlugin"))
}
