#include "include/zebra_plugin/zebra_plugin_c_api.h"

#include <flutter/plugin_registrar_windows.h>

#include "zebra_plugin.h"

void ZebraPluginCApiRegisterWithRegistrar(
    FlutterDesktopPluginRegistrarRef registrar) {
  zebra_plugin::ZebraPlugin::RegisterWithRegistrar(
      flutter::PluginRegistrarManager::GetInstance()
          ->GetRegistrar<flutter::PluginRegistrarWindows>(registrar));
}
