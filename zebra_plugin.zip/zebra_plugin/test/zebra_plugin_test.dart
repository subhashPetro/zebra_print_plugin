import 'package:flutter_test/flutter_test.dart';
import 'package:zebra_plugin/zebra_plugin.dart';
import 'package:zebra_plugin/zebra_plugin_platform_interface.dart';
import 'package:zebra_plugin/zebra_plugin_method_channel.dart';
import 'package:plugin_platform_interface/plugin_platform_interface.dart';

class MockZebraPluginPlatform
    with MockPlatformInterfaceMixin
    implements ZebraPluginPlatform {

  @override
  Future<String?> getPlatformVersion() => Future.value('42');
}

void main() {
  final ZebraPluginPlatform initialPlatform = ZebraPluginPlatform.instance;

  test('$MethodChannelZebraPlugin is the default instance', () {
    expect(initialPlatform, isInstanceOf<MethodChannelZebraPlugin>());
  });

  test('getPlatformVersion', () async {
    ZebraPlugin zebraPlugin = ZebraPlugin();
    MockZebraPluginPlatform fakePlatform = MockZebraPluginPlatform();
    ZebraPluginPlatform.instance = fakePlatform;

    expect(await zebraPlugin.getPlatformVersion(), '42');
  });
}
