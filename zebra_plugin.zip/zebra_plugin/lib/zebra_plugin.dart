
import 'zebra_plugin_platform_interface.dart';

class ZebraPlugin {
  Future<String?> getPlatformVersion() {
    return ZebraPluginPlatform.instance.getPlatformVersion();
  }
}
